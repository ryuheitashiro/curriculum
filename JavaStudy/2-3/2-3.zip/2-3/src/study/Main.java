package study;

public class Main {

	public static void main(String[] args) {
		// ③ Taskクラスのインスタンスを生成し、「doTask()」メソッドを呼び出しなさい。
		Task task = new Task();
		task.doTask();

	}

}
